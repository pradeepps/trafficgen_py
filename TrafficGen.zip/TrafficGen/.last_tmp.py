import VisitWebPages
import sl4a
import time
import threading

droid = sl4a.Android()

def isIpChanged():
    title = 'IP Changing Alert!'
    message = 'Did you change IP?'
    droid.dialogCreateAlert(title, message)
    droid.dialogSetPositiveButtonText('Yes')
    droid.dialogSetNegativeButtonText('No')
    droid.dialogShow()
    response = droid.dialogGetResponse().result  
    if(response['which']=='positive'):
        title = 'IP Changing Confirm Alert!'
        message = 'Did you change IP?'
        droid.dialogCreateAlert(title, message)
        droid.dialogSetPositiveButtonText('Yes')
        droid.dialogSetNegativeButtonText('No')
        droid.dialogShow()
        response = droid.dialogGetResponse().result
        if(response['which']=='positive'):
            return True
        else:
            return False    
    else:
        return False

  

if(isIpChanged()):
    print('IP is changed')
else:
    print('No')       


class myThread (threading.Thread):
    def __init__(self, v1, v2):
        threading.Thread.__init__(self)
        self.v1=v1
        self.v2=v2    
    def run(self):
        print(self.v1,self.v2)
        

thread1 = myThread(1, "Thread-1")
thread2 = myThread(2, "Thread-2")

thread1.start()
thread2.start()
thread1.join()
thread2.join()

'''
for a in range(1,10):
    print()
    ud=VisitWebPages.viewAds("/storage/emulated/0/qpython/Files/u"+str(a))

    print()
    print(ud[0])
    print(ud[1])
    print()
    print()

'''