from urllib.request import Request, urlopen 


adPages=[]
adPages.append("http://d.com/1.php")
adPages.append("http://d.com/2.php")
adPages.append("http://d.com/3.php")
adPages.append("http://d.com/4.php")
adPages.append("http://d.com/5.php")

data=[]
#url,postData
data.append(["ad.1",""])
data.append(["ad.2",""])
data.append(["ad.3",""])

adsPerPage=len(data)


def load(ua,cookie,referer,ad):
    return sendData(data[ad][0],data[ad][1],ua,cookie,referer)    
      
    
def sendData(url,postData,ua,cookie,referer):
    newCookie=""
    print(ua,referer,url)
    
    try:
        req = Request(url)
        req.add_header('Referer',referer) 
        req.add_header('User-Agent',ua) 
        req.add_header('Cookie',cookie)
        if postData=="":
            res = urlopen(req)  
            newCookie=res.getheader('Set-Cookie')                      
        else:
            res = urlopen(req, data=str.encode(postData))
            newCookie=res.getheader('Set-Cookie')      

    except:
        pass    

    return newCookie

