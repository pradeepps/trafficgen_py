import os
import random
import RequestLink


userAgents=[]
userAgents.append("moss")
userAgents.append("cho")
userAgents.append("ex")
userAgents.append("ope")
userAgents.append("bir")
userAgents.append("zin")
userAgents.append("dol")
userAgents.append("sam")
userAgents.append("intt")
userAgents.append("att")       

adsPerPage=RequestLink.adsPerPage


def viewAds(userdir):    
    ua=""
    cookie=""
    newCookie=""            
  
    try:
        os.mkdir(userdir)
    except:
        pass

    try:
        f=open(userdir+"/ua.txt","r")
        ua=f.read()
        f.close()
    except:
        f=open(userdir+"/ua.txt","w")
        ua=random.choice(userAgents)
        f.write(ua)
        f.close()
    
    try:
        f=open(userdir+"/cookie.txt","r")
        cookie=f.read()
        f.close()
    except:
        f=open(userdir+"/cookie.txt","w")
        f.close()

    adPages=[]
    for ap in RequestLink.adPages:
        adPages.append(ap)
        
    r=random.randrange(2,5,1)
    
    for pg in range(r):
        r1=random.randrange(len(adPages))
        adPg=adPages.pop(r1)
        for ad in range(adsPerPage):         
            newCookie=RequestLink.load(ua,cookie,adPg,ad)
            cookie=setCookie(newCookie,cookie)                                                                  
             
    f=open(userdir+"/cookie.txt","w")
    f.write(cookie)
    f.close()
    
    return [ua,cookie]
    

def setCookie(newCookie,cookie):
    c1=newCookie.split(";")[0].split(",")
    c2=cookie.split(";")
    cs=c2
    st=""   
    
    for c in c1:
        r=isCookieIn(c,c2)
        if(r>=0):       
            cs[r]=c
        else:
            cs.append(c)
            
    for c in cs:
        if(len(c)>0):
            st=st+c+";"
    
    if(len(st)>0):
        st=st[0:(len(st)-1)]
    return st

        
def isCookieIn(c,c2):
    for a in range(0,len(c2)):            
        if(c.split("=")[0]== c2[a].split("=")[0]):
            return a
    return -1
    


